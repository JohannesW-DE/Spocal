package dev.weinsheimer.sportscalendar.util

import android.view.View
import androidx.databinding.BindingAdapter

/**
 * Binding adapter used to show add button once an item is selected
 */
@BindingAdapter("app:visibleIfNotNull")
fun visibleIfNotNull(view: View, it: Any?) {
    view.visibility = if (it != null) View.VISIBLE else View.GONE
}