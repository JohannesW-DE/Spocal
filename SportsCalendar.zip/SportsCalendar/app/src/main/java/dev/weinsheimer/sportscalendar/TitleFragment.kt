package dev.weinsheimer.sportscalendar


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import dev.weinsheimer.sportscalendar.databinding.FragmentTitleBinding

class TitleFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: FragmentTitleBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_title, container, false)
        binding.fragmentTitleTextView.setOnClickListener {view: View ->
            //Navigation.createNavigateOnClickListener(R.id.action_titleFragment_to_calendarFragment)
            view.findNavController().navigate(TitleFragmentDirections.actionTitleFragmentToCalendarFragment())
        }
        return binding.root
    }
}
