package dev.weinsheimer.sportscalendar.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import dev.weinsheimer.sportscalendar.R
import dev.weinsheimer.sportscalendar.database.Event
import dev.weinsheimer.sportscalendar.databinding.BadmintonAthleteRowBinding
import dev.weinsheimer.sportscalendar.domain.BadmintonAthlete
import timber.log.Timber

class BadmintonAthleteAdapter(context: Context,
                              athleteList: List<BadmintonAthlete>) :
    ArrayAdapter<BadmintonAthlete>(context, 0, athleteList) {

    private lateinit var binding: BadmintonAthleteRowBinding

    var completeList: ArrayList<BadmintonAthlete> = ArrayList(athleteList)

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                var suggestions = mutableListOf<BadmintonAthlete>()

                if (constraint.isNullOrBlank()) {
                    suggestions.addAll(completeList)
                } else {
                    val pattern = constraint.trim()
                    for (athlete in completeList) {
                        if (athlete.name.contains(pattern, ignoreCase = true)) {
                            suggestions.add(athlete)
                        }
                    }
                }
                return FilterResults().apply {
                    values = suggestions
                    count = suggestions.size
                }
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                clear()
                results?.let {
                    @Suppress("UNCHECKED_CAST")
                    addAll(results.values as List<BadmintonAthlete>)
                }
                notifyDataSetChanged()
            }

            override fun convertResultToString(resultValue: Any?): CharSequence {
                return (resultValue as BadmintonAthlete).name
            }
        }
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        binding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.badminton_athlete_row,
            parent,
            false)

        getItem(position)?.let {athlete ->
            binding.athlete = athlete
        }

        return binding.root
    }
}
