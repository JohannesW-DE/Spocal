package dev.weinsheimer.sportscalendar.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import dev.weinsheimer.sportscalendar.database.getDatabase
import dev.weinsheimer.sportscalendar.domain.BadmintonAthlete
import dev.weinsheimer.sportscalendar.domain.BadmintonFilter
import dev.weinsheimer.sportscalendar.repository.BadmintonRepository
import dev.weinsheimer.sportscalendar.repository.CountriesRepository
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * SharedViewModel acts as a store for (at least) api related data. AndroidViewModel is subclassed because the
 * application context is needed for managing the room database.
 */
class SharedViewModel(application: Application) : AndroidViewModel(application) {
    private val database = getDatabase(application)
    private val countriesRepository = CountriesRepository(database)
    private val badmintonRepository = BadmintonRepository(database)

    val countries = countriesRepository.countries
    val badmintonAthletes = badmintonRepository.athletes
    val badmintonEventCategories = badmintonRepository.eventCategories

    val badmintonFilter: MutableLiveData<BadmintonFilter> by lazy {
        MutableLiveData<BadmintonFilter>()
    }
    val badmintonFilterSelectedAthlete: MutableLiveData<BadmintonAthlete> by lazy {
        MutableLiveData<BadmintonAthlete>()
    }

    fun addToBadmintonFilter(type: String) {
        when(type) {
            "athlete" -> {
                 if (!badmintonFilter.value?.athletes?.contains(badmintonFilterSelectedAthlete.value)!!) {
                    badmintonFilter.value?.athletes?.add(badmintonFilterSelectedAthlete.value!!)
                    Timber.i("ADDDED")
                    badmintonFilter.value = badmintonFilter.value
                }
            }
            else -> throw ClassCastException("Unknown object typej")
        }
    }
    fun debug() {
        badmintonRepository.debug()
    }

    fun onBadmintonAthleteClicked(athlete: BadmintonAthlete) {
        Timber.i(athlete.toString())
    }

    init {
        viewModelScope.launch {
            countriesRepository.refreshCountries()
            badmintonRepository.refreshAthletes()
            badmintonRepository.refreshCategories()
        }
    }
}