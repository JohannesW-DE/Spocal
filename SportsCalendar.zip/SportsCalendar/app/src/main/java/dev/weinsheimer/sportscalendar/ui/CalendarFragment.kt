package dev.weinsheimer.sportscalendar.ui

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.NavigationUI
import dev.weinsheimer.sportscalendar.*
import dev.weinsheimer.sportscalendar.databinding.FragmentCalendarBinding
import dev.weinsheimer.sportscalendar.viewmodels.SharedViewModel

class CalendarFragment : Fragment() {
    private lateinit var binding: FragmentCalendarBinding

    private lateinit var viewModel : CalendarViewModel


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater,
            R.layout.fragment_calendar, container, false)
        Log.i("CalendarFragment", "ViewModelProviders.of called")
        viewModel = ViewModelProviders.of(this).get(CalendarViewModel::class.java)




        binding.calendarViewModel = viewModel

        // refresh events
        binding.button.setOnClickListener{
            viewModel.updateEvents()
        }

        viewModel.foo.observe(this, Observer {
            binding.eventsTextView.text = it
        } )

        // redirect the adapters onClick events to the viewmodel
        val adapter =
            CalendarAdapter(CalendarListener { sport, name ->
                viewModel.onEventClicked(sport, name)
            })
        // Toast.makeText(context, "$name", Toast.LENGTH_LONG).show()

        viewModel.navigateToEventDetails.observe(this, Observer { event -> event?.let {
            this.findNavController().navigate(
                CalendarFragmentDirections.actionCalendarFragmentToEventDetailsFragment(
                    "xd",
                    event
                )
            )
            //this.findNavController().navigate(CalendarFragmentDirections.actionCalendarFragmentToFooFragment())
            viewModel.onEventDetailsNavigated()
        }})


        binding.calendarRecyclerView.adapter = adapter
        viewModel.events.observe(viewLifecycleOwner, Observer {
            it?.let {
                adapter.addMonthAndSubmitList(it)
            }
        })

        setHasOptionsMenu(true)

        return binding.root
    }

}
