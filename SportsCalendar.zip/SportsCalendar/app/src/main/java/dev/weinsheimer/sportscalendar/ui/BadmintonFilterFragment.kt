package dev.weinsheimer.sportscalendar.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import dev.weinsheimer.sportscalendar.R
import dev.weinsheimer.sportscalendar.databinding.FragmentBadmintonFilterBinding
import dev.weinsheimer.sportscalendar.domain.BadmintonAthlete
import dev.weinsheimer.sportscalendar.domain.BadmintonEventCategory
import dev.weinsheimer.sportscalendar.domain.Country
import dev.weinsheimer.sportscalendar.viewmodels.SharedViewModel
import timber.log.Timber

class BadmintonFilterFragment : Fragment() {
    private lateinit var binding: FragmentBadmintonFilterBinding
    private lateinit var viewModel: SharedViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_badminton_filter, container, false)

        viewModel = activity?.run {
            ViewModelProviders.of(this).get(SharedViewModel::class.java)
        } ?: throw Exception("Invalid Activity")

        viewModel.badmintonAthletes.observe(viewLifecycleOwner, Observer { athletes ->
            binding.athleteAutoCompleteTextView.setAdapter(
                athletes?.let {
                    //BadmintonAthleteAdapter(context!!, it, BadmintonAthleteListener { athlete ->
                    //    viewModel.onBadmintonAthleteClicked(athlete)
                    //})
                    //ArrayAdapter(context!!, android.R.layout.simple_list_item_1, athletes)
                    BadmintonAthleteAdapter(context!!, it)
                }
            )

        })

        binding.athleteAutoCompleteTextView.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {

            }
        }

        viewModel.badmintonFilterSelectedAthlete.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                binding.athleteImageButton.visibility = View.VISIBLE
            } else {
                binding.athleteImageButton.visibility = View.GONE
            }
        })

        binding.athleteAutoCompleteTextView.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->
                val athlete = binding.athleteAutoCompleteTextView.adapter.getItem(position) as BadmintonAthlete
                viewModel.badmintonFilterSelectedAthlete.postValue(athlete)
            }

        binding.athleteAutoCompleteTextView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                viewModel.badmintonFilterSelectedAthlete.value = null
            }
        })

        viewModel.badmintonEventCategories.observe(viewLifecycleOwner, Observer { eventCategories ->
            binding.eventCategorySpinner.adapter = eventCategories?.let {
                Timber.i(it.toString())
                ArrayAdapter(context!!, android.R.layout.simple_spinner_item, it)
            }
        })

        binding.eventCategorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val category = binding.eventCategorySpinner.adapter.getItem(position) as BadmintonEventCategory
                Timber.i("yooooooooo:")
                Timber.i(category.toString())
            }
        }

        viewModel.badmintonFilter.observe(viewLifecycleOwner, Observer {
            Timber.i("FILTER UPDATED")
        })

        binding.athleteImageButton.setOnClickListener {
            viewModel.addToBadmintonFilter("athlete")
        }

        // debug
        binding.button.setOnClickListener{
            viewModel.debug()
        }

        return binding.root
    }

}