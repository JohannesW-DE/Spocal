package dev.weinsheimer.sportscalendar.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import dev.weinsheimer.sportscalendar.database.SpocalDB
import dev.weinsheimer.sportscalendar.database.asDomainModel
import dev.weinsheimer.sportscalendar.domain.Country
import dev.weinsheimer.sportscalendar.network.Api
import dev.weinsheimer.sportscalendar.network.asDatabaseModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CountriesRepository(private val database: SpocalDB) {
    val countries: LiveData<List<Country>> =
        Transformations.map(database.countryDao.getCountries()) {
            it.asDomainModel()
        }

    suspend fun refreshCountries() {
        withContext(Dispatchers.IO) {
            val container = Api.retrofitService.getCountries()
            database.countryDao.insertAll(*container.asDatabaseModel())
        }
    }
}