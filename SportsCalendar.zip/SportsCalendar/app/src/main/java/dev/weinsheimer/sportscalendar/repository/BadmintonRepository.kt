package dev.weinsheimer.sportscalendar.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import dev.weinsheimer.sportscalendar.database.DatabaseBadmintonEventCategory
import dev.weinsheimer.sportscalendar.database.SpocalDB
import dev.weinsheimer.sportscalendar.database.asDomainModel
import dev.weinsheimer.sportscalendar.domain.BadmintonAthlete
import dev.weinsheimer.sportscalendar.domain.BadmintonEventCategory
import dev.weinsheimer.sportscalendar.domain.Country
import dev.weinsheimer.sportscalendar.network.Api
import dev.weinsheimer.sportscalendar.network.asDatabaseModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber

class BadmintonRepository(private val database: SpocalDB) {
    val athletes: LiveData<List<BadmintonAthlete>> =
        Transformations.map(database.badmintonDao.getAthletes()) {
            it.asDomainModel()
        }

    val eventCategories: LiveData<List<BadmintonEventCategory>> =
        Transformations.map(database.badmintonDao.getEventCategories()) { list ->
            list.map { category ->
                BadmintonEventCategory(category.sh, category.name, null)
            }
        }

    fun debug() {
        Timber.i("debug")
        Timber.i(eventCategories.value.toString())
    }

    suspend fun refreshAthletes() {
        withContext(Dispatchers.IO) {
            val container = Api.retrofitService.getBadmintonAthletes()
            database.badmintonDao.insertAll(*container.asDatabaseModel())
        }
    }

    suspend fun refreshCategories() {
        withContext(Dispatchers.IO) {
            val container = Api.retrofitService.getBadmintonEventCategories()
            Timber.i(container.categories.toString())
            for (category in container.categories) {
                database.badmintonDao.insertEventCategory(
                    category.let {
                        DatabaseBadmintonEventCategory(sh = it.short, name = it.name, subcategoryOf = null)
                    }
                )
                category.subcategories?.forEach { subcategory ->
                    database.badmintonDao.insertEventCategory(
                        subcategory.let {
                            DatabaseBadmintonEventCategory(sh = it.short, name = it.name, subcategoryOf = category.short)
                        }
                    )
                }
            }
        }
    }
}