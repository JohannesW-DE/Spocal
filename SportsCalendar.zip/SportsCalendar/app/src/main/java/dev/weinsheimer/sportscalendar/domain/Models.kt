package dev.weinsheimer.sportscalendar.domain

data class Country(val id: Int,
                   val name: String,
                   val alphatwo: String?) {
    override fun toString(): String = name
}

data class BadmintonAthlete(val id: Int,
                            val name: String,
                            val nationality: Int) {
    override fun toString(): String = name
}

data class BadmintonEventCategory(val short: String,
                                  val name: String,
                                  val subcategories: List<BadmintonEventCategory>?) {
    override fun toString(): String = name
}

data class BadmintonFilter(var athletes: MutableList<BadmintonAthlete> = mutableListOf(),
                           var categories: MutableList<BadmintonEventCategory>  = mutableListOf())