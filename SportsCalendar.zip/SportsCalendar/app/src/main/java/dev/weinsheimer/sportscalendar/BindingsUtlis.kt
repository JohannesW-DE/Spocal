package dev.weinsheimer.sportscalendar

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import dev.weinsheimer.sportscalendar.database.Event

@BindingAdapter("eventIcon")
fun ImageView.setEventIcon(item: Event) {
    setImageResource(
        when (item.sport) {
            "badminton" -> R.drawable.ic_badminton
            "cycling" -> R.drawable.ic_cycling
            else -> R.drawable.ic_cycling
        }
    )
}