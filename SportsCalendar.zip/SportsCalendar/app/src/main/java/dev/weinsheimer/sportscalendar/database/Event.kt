package dev.weinsheimer.sportscalendar.database

data class Event(
    var sport: String = "",
    var name: String = ""
)
