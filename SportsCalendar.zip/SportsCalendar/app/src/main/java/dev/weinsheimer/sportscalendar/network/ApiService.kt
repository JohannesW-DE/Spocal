package dev.weinsheimer.sportscalendar.network

import androidx.annotation.Nullable
import com.squareup.moshi.FromJson
import com.squareup.moshi.JsonQualifier
import com.squareup.moshi.Moshi
import com.squareup.moshi.ToJson
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

private const val BASE_URL = "http://10.0.2.2:5000"

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(BASE_URL)
    .build()

interface ApiService {
    @GET("badminton/events")
    suspend fun getEvents(): NetworkEventResponse

    @GET("countries")
    suspend fun getCountries(): NetworkCountryContainer

    @GET("badminton/athletes")
    suspend fun getBadmintonAthletes(): NetworkBadmintonAthletesContainer

    @GET("badminton/categories")
    suspend fun getBadmintonEventCategories(): NetworkBadmintonEventCategoriesContainer
}

object Api {
    val retrofitService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}