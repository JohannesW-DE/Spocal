package dev.weinsheimer.sportscalendar.network

import dev.weinsheimer.sportscalendar.database.DatabaseBadmintonAthlete
import dev.weinsheimer.sportscalendar.database.DatabaseBadmintonEventCategory
import dev.weinsheimer.sportscalendar.database.DatabaseCountry
import dev.weinsheimer.sportscalendar.domain.Country

data class NetworkEventResponse(
    val events: List<NetworkEvent>
)

data class NetworkEvent(
    val id: Double,
    val category: String,
    val name: String
)

// COUNTRY

// parses the return: {"countries":[...]}
data class NetworkCountryContainer(val countries: List<NetworkCountry>)

data class NetworkCountry(
    val id: Int,
    val name: String,
    val alphatwo: String?)

fun NetworkCountryContainer.asDomainModel(): List<Country> {
    return countries.map {
        Country (
            id = it.id,
            name = it.name,
            alphatwo = it.alphatwo)
    }
}

fun NetworkCountryContainer.asDatabaseModel(): Array<DatabaseCountry> {
    return countries.map {
        DatabaseCountry (
            id = it.id,
            name = it.name,
            alphatwo = it.alphatwo)
    }.toTypedArray()
}

// BADMINTON ATHLETE
data class NetworkBadmintonAthletesContainer(val athletes: List<NetworkBadmintonAthlete>)

data class NetworkBadmintonAthlete(
    val id: Int,
    val name: String,
    val nationality: Int)

fun NetworkBadmintonAthletesContainer.asDatabaseModel(): Array<DatabaseBadmintonAthlete> {
    return athletes.map {
        DatabaseBadmintonAthlete (
            id = it.id,
            name = it.name,
            nationality = it.nationality)
    }.toTypedArray()
}

// BADMINTON EVENT CATEGORY
data class NetworkBadmintonEventCategoriesContainer(val categories: List<NetworkBadmintonEventCategory>)

data class NetworkBadmintonEventCategory(
    val short: String,
    val name: String,
    val subcategories: List<NetworkBadmintonEventCategory>?
)
