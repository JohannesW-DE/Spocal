package dev.weinsheimer.sportscalendar.database

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.Database

@Dao
interface CountryDao {
    @Query("select * from databasecountry")
    fun getCountries(): LiveData<List<DatabaseCountry>>

    // vararg: kotlins way of taking an unknown number of arguments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg videos: DatabaseCountry)
}

@Dao
interface BadmintonDao {
    @Insert
    fun insertEventCategory(category: DatabaseBadmintonEventCategory)

    @Query("SELECT * FROM databasebadmintoneventcategory WHERE subcategory_of IS NULL")
    fun getEventCategories(): LiveData<List<DatabaseBadmintonEventCategory>>

    @Query("SELECT * FROM databasebadmintoneventcategory WHERE subcategory_of = :category")
    fun getEventSubcategories(category: String): LiveData<List<DatabaseBadmintonEventCategory>>

    /*
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllEventCategories(vararg categories: DatabaseBadmintonEventCategory)
    */

    @Query("select * from databasebadmintonathlete")
    fun getAthletes(): LiveData<List<DatabaseBadmintonAthlete>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg athletes: DatabaseBadmintonAthlete)


}


@Database(entities = [DatabaseCountry::class, DatabaseBadmintonAthlete::class, DatabaseBadmintonEventCategory::class], version = 1)
abstract class SpocalDB: RoomDatabase() {
    abstract val countryDao: CountryDao
    abstract val badmintonDao: BadmintonDao
}

private lateinit var INSTANCE: SpocalDB

fun getDatabase(context: Context): SpocalDB {
    synchronized(SpocalDB::class.java) {
        if (!::INSTANCE.isInitialized) {
            INSTANCE = Room.databaseBuilder(context.applicationContext, SpocalDB::class.java, "spocal").build()
        }
        return INSTANCE
    }
}


