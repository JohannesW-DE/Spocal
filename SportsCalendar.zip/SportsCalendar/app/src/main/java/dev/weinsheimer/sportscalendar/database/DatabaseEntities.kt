package dev.weinsheimer.sportscalendar.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import dev.weinsheimer.sportscalendar.domain.BadmintonAthlete
import dev.weinsheimer.sportscalendar.domain.Country

// DatabaseCountry
@Entity
data class DatabaseCountry constructor(
    @PrimaryKey
    val id: Int,
    val name: String,
    val alphatwo: String?)

// extension function to convert from database object to domain object
@JvmName("databaseCountryToDomainModel")
fun List<DatabaseCountry>.asDomainModel(): List<Country> {
    return map {
        Country(
            id = it.id,
            name = it.name,
            alphatwo = it.alphatwo)
    }
}

// DatabaseBadmintonAthlete
@Entity
data class DatabaseBadmintonAthlete constructor(
    @PrimaryKey
    val id: Int,
    val name: String,
    val nationality: Int)

@JvmName("databaseBadmintonAthleteToDomainModel")
fun List<DatabaseBadmintonAthlete>.asDomainModel(): List<BadmintonAthlete> {
    return map {
        BadmintonAthlete(
            id = it.id,
            name = it.name,
            nationality = it.nationality)
    }
}

// DatabaseBadmintonEventCategory
@Entity
data class DatabaseBadmintonEventCategory constructor(
    @PrimaryKey
    val sh: String,
    val name: String,
    @ColumnInfo(name = "subcategory_of") val subcategoryOf: String?)
