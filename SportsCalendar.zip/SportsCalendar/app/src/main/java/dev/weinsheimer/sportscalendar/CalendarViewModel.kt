package dev.weinsheimer.sportscalendar


import android.app.Application
import android.util.Log
import androidx.annotation.UiThread
import androidx.lifecycle.*
import dev.weinsheimer.sportscalendar.database.Event
import dev.weinsheimer.sportscalendar.database.getDatabase
import dev.weinsheimer.sportscalendar.domain.Country
import dev.weinsheimer.sportscalendar.network.*
import dev.weinsheimer.sportscalendar.repository.CountriesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import timber.log.Timber


class CalendarViewModel(application: Application) : AndroidViewModel(application) {
    var foo =  MutableLiveData<String>()
    var events = MutableLiveData<List<Event>>()

    private val _response = MutableLiveData<String>()
    val response
        get() = _response

    private val _navigateToEventDetails = MutableLiveData<String>()
    val navigateToEventDetails
        get() = _navigateToEventDetails


    // repository stuff
    private val database = getDatabase(application)
    private val countriesRepository = CountriesRepository(database)

    // countries
    val countries = countriesRepository.countries

    init {
        Log.i("CalendarViewModel", "CalendarViewModel created")
        foo.value = "bar"
        events.value = listOf(
            Event("badminton", "Badminton Event 1"),
            Event("badminton", "Badminton Event 2"),
            Event("badminton", "Badminton Event 3"),
            Event("cycling", "Cycling Event 1"),
            Event("cycling", "Cycling Event 2"),
            Event("cycling", "Cycling Event 3"))

        // fetch stuff
        viewModelScope.launch {
            countriesRepository.refreshCountries()
        }
    }

    fun onEventClicked(sport: String, name: String) {
        _navigateToEventDetails.value = name
    }

    fun onEventDetailsNavigated() {
        _navigateToEventDetails.value = null
    }

    fun updateEvents() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = Api.retrofitService.getEvents()
                Log.i("CalendarViewModel", response.events.size.toString())
            } catch (e: Exception) {
                Log.i("CalendarViewModel", "Faaaaaaaaaaaaail")
            }
        }
    }

    fun bar() {
        foo.value = arrayOf("Tournament 1", "Tournament2", "Tournament 3", "Tournament 4", "Tournament 5").random()
    }

    override fun onCleared() {
        super.onCleared()
        Log.i("CalendarViewModel", "CalendarViewModel destroyed")
    }
}