package dev.weinsheimer.sportscalendar

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import dev.weinsheimer.sportscalendar.database.Event
import dev.weinsheimer.sportscalendar.databinding.FragmentCalendarItemBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val ITEM_VIEW_TYPE_MONTH = 0
private const val ITEM_VIEW_TYPE_EVENT = 1

class CalendarAdapter(val clickListener: CalendarListener): ListAdapter<DataItem, RecyclerView.ViewHolder>(CalendarDiffCallback()) {
    private val adapterScope = CoroutineScope(Dispatchers.Default)


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is ViewHolder -> {
                val eventItem = getItem(position) as DataItem.EventItem
                holder.bind(eventItem.event, clickListener)
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when(getItem(position)) {
            is DataItem.MonthItem -> ITEM_VIEW_TYPE_MONTH
            is DataItem.EventItem -> ITEM_VIEW_TYPE_EVENT
        }
    }

    fun addMonthAndSubmitList(list: List<Event>?) {
        adapterScope.launch {
            val items = when(list) {
                null -> listOf(DataItem.MonthItem("January"))
                else -> listOf(DataItem.MonthItem("January")) + list.map{ DataItem.EventItem(it)} + listOf(DataItem.MonthItem("January")) + list.map{ DataItem.EventItem(it)}
            }
            withContext(Dispatchers.Main) {
                submitList(items)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            ITEM_VIEW_TYPE_MONTH -> TextViewHolder.from(parent)
            ITEM_VIEW_TYPE_EVENT -> ViewHolder.from(parent)
            else -> throw ClassCastException("Unknown viewType $viewType")
        }
    }

    // private constructor -> can only be called by companion object
    class ViewHolder private constructor(val binding: FragmentCalendarItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(
            item: Event,
            clickListener: CalendarListener
        ) {
            binding.event = item
            binding.fciNameTextView.text = item.name
            binding.executePendingBindings()
            binding.clickListener = clickListener
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = FragmentCalendarItemBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }

    class TextViewHolder(view: View): RecyclerView.ViewHolder(view) {

        companion object {
            fun from(parent: ViewGroup): TextViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val view = layoutInflater.inflate(R.layout.fragment_calendar_month, parent, false)
                return TextViewHolder(view)
            }
        }
    }
}

class CalendarDiffCallback : DiffUtil.ItemCallback<DataItem>() {
    override fun areItemsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
        return (oldItem.id == oldItem.id)
    }

    override fun areContentsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
        // fields are compared because data class
        return oldItem == newItem
    }
}

class CalendarListener(val clickListener: (sport: String, name: String) -> Unit) {
    fun onClick(event: Event) = clickListener(event.sport, event.name)
}

sealed class DataItem {
    data class EventItem(val event: Event) : DataItem() {
        override val id = event.name
    }
    data class MonthItem(val month: String) : DataItem() {
        override val id = month
    }

    abstract val id: String
}