package dev.weinsheimer.sportscalendar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import dev.weinsheimer.sportscalendar.databinding.FragmentEventDetailsBinding

class EventDetailsFragment : Fragment() {
    private lateinit var binding: FragmentEventDetailsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_event_details, container, false)

        var args = EventDetailsFragmentArgs.fromBundle(arguments!!)
        Toast.makeText(context, args.name, Toast.LENGTH_LONG).show()

        return binding.root
    }
}